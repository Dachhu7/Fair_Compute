import asyncio

from fair_compute_api import query_llava

async def answer_question(image_data):
    prompt = "What is in this picture?"
    model_version = "34b-v1.6"
    
    response = await query_llava(model_version, prompt, image_data)
    return response

# Example usage
async def main():
    image_data = "base64_encoded_image_string"
    response = await answer_question(image_data)
    print(response)

if __name__ == "__main__":
    asyncio.run(main())
