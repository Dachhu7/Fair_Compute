import cv2
import asyncio
import base64
import numpy as np
from fair_compute_api import query_llava

async def analyze_security_feed(image):
    prompt = "Detect security threats in this image."
    model_version = "34b-v1.6"

    # Convert image to base64
    _, encoded_image = cv2.imencode('.jpg', image)
    image_data = base64.b64encode(encoded_image).decode('utf-8')
    
    response = await query_llava(model_version, prompt, image_data)
    return response

# Example usage
async def main():
    # Capture image from camera (example)
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    cap.release()

    # Process image
    if ret:
        response = await analyze_security_feed(frame)
        print(response)
    else:
        print("Error capturing image.")

if __name__ == "__main__":
    asyncio.run(main())
