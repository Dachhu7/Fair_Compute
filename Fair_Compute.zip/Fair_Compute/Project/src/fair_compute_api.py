import aiohttp
import asyncio
import json
import time

async def fetch(session, url, data):
    async with session.post(url, data=data) as response:
        return await response.text()

async def query_llava(model_version, prompt, image_data):
    url = "http://35.233.231.20:5003/api/generate"
    data = json.dumps({
        "model": f"llava:{model_version}",
        "prompt": prompt,
        "stream": False,
        "images": [image_data]
    })
    headers = {'Content-Type': 'application/json'}
    
    async with aiohttp.ClientSession(headers=headers) as session:
        return await fetch(session, url, data)
